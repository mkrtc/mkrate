# `@mkrate/bridge-protocol`

Canonical, intentionally incompatible trusted Bridge v1 wire contract shared by
Mkrate Bridge, Desktop, and Mobile.

The package exports strict versioned schemas and parsers for `/v1/desktop` and
`/v1/mobile`, the exact command allowlist, finite errors, security limits,
canonical 32-byte token hashing, QR/manual pairing helpers, timeline and cursor
contracts, and deterministic language-neutral conformance vectors.

This package is independent from `@mkrate/relay-protocol` and
`@mkrate/relay-crypto`. Bridge v1 uses TLS/WSS and opaque random bearer tokens;
it does not use JWT or application-layer custom cryptography.

```sh
bun run typecheck
bun test tests
bun run check:conformance
bun run verify:pack
```

See [`../../docs/bridge-security-contract.md`](../../docs/bridge-security-contract.md)
and [`../../docs/bridge-protocol.md`](../../docs/bridge-protocol.md).
